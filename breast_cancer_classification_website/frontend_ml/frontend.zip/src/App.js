import React from 'react'
import "./App.css"
import HomePage from './components/HomePage'
const App = () => {
  return (
    <div className='app'>
      <HomePage/>
    </div>
  )
}

export default App






